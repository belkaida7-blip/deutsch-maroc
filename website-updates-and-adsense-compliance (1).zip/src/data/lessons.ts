export interface Lesson {
  id: number;
  title: string;
  titleDe: string;
  description: string;
  category: string;
  duration: string;
  content: {
    intro: string;
    vocabulary: { de: string; ar: string; example?: string }[];
    grammar?: { rule: string; example: string; translation: string }[];
    dialogue?: { speaker: string; de: string; ar: string }[];
    tips?: string[];
  };
}

export interface Level {
  id: string;
  name: string;
  nameAr: string;
  nameDe: string;
  color: string;
  bgColor: string;
  borderColor: string;
  description: string;
  hours: string;
  lessons: Lesson[];
}

const a1Lessons: Lesson[] = [
  {
    id: 1, title: "التحيات والمقدمات", titleDe: "Begrüßungen und Vorstellungen",
    description: "تعلم كيف تقول مرحباً وتقدّم نفسك بالألمانية",
    category: "تواصل", duration: "20 دقيقة",
    content: {
      intro: "في هذا الدرس ستتعلم أهم عبارات التحية والتعارف في اللغة الألمانية.",
      vocabulary: [
        { de: "Hallo", ar: "مرحباً", example: "Hallo, ich bin Ahmad." },
        { de: "Guten Morgen", ar: "صباح الخير", example: "Guten Morgen! Wie geht es Ihnen?" },
        { de: "Guten Tag", ar: "مرحباً (نهاراً)", example: "Guten Tag, mein Name ist Sara." },
        { de: "Guten Abend", ar: "مساء الخير", example: "Guten Abend! Willkommen." },
        { de: "Auf Wiedersehen", ar: "مع السلامة", example: "Tschüss! Auf Wiedersehen!" },
        { de: "Tschüss", ar: "وداعاً (غير رسمي)", example: "Tschüss, bis morgen!" },
        { de: "Danke", ar: "شكراً", example: "Danke schön!" },
        { de: "Bitte", ar: "من فضلك / عفواً", example: "Bitte, kommen Sie herein." },
        { de: "Ja", ar: "نعم", example: "Ja, natürlich!" },
        { de: "Nein", ar: "لا", example: "Nein, danke." },
      ],
      dialogue: [
        { speaker: "أحمد", de: "Hallo! Ich heiße Ahmad. Wie heißt du?", ar: "مرحباً! اسمي أحمد. ما اسمك؟" },
        { speaker: "سارة", de: "Hallo Ahmad! Ich bin Sara. Woher kommst du?", ar: "مرحباً أحمد! أنا سارة. من أين أنت؟" },
        { speaker: "أحمد", de: "Ich komme aus Marokko. Und du?", ar: "أنا من المغرب. وأنت؟" },
        { speaker: "سارة", de: "Ich komme aus Deutschland. Schön, dich kennenzulernen!", ar: "أنا من ألمانيا. سعيدة بمعرفتك!" },
      ],
      tips: [
        "استخدم 'Sie' (صيغة المؤدب) مع الغرباء والكبار في السن",
        "'du' تستخدم مع الأصدقاء والأطفال",
        "الألمان يقدّرون اللياقة والمؤدبية في التحيات",
      ],
    },
  },
  {
    id: 2, title: "الأرقام من 1 إلى 100", titleDe: "Zahlen 1-100",
    description: "تعلم الأرقام الألمانية وكيف تستخدمها في الحياة اليومية",
    category: "أساسيات", duration: "25 دقيقة",
    content: {
      intro: "الأرقام أساسية في كل لغة. تعلمها سيساعدك في التسوق والمواصلات والتواصل اليومي.",
      vocabulary: [
        { de: "eins (1)", ar: "واحد" }, { de: "zwei (2)", ar: "اثنان" },
        { de: "drei (3)", ar: "ثلاثة" }, { de: "vier (4)", ar: "أربعة" },
        { de: "fünf (5)", ar: "خمسة" }, { de: "sechs (6)", ar: "ستة" },
        { de: "sieben (7)", ar: "سبعة" }, { de: "acht (8)", ar: "ثمانية" },
        { de: "neun (9)", ar: "تسعة" }, { de: "zehn (10)", ar: "عشرة" },
        { de: "zwanzig (20)", ar: "عشرون" }, { de: "dreißig (30)", ar: "ثلاثون" },
        { de: "vierzig (40)", ar: "أربعون" }, { de: "fünfzig (50)", ar: "خمسون" },
        { de: "hundert (100)", ar: "مئة" },
      ],
      tips: [
        "الأرقام 13-19 تنتهي بـ '-zehn': dreizehn، vierzehn...",
        "العشرات تنتهي بـ '-zig': zwanzig، dreißig...",
        "للتركيب: einundzwanzig (21) = eins + und + zwanzig",
      ],
    },
  },
  {
    id: 3, title: "الألوان", titleDe: "Die Farben",
    description: "تعلم أسماء الألوان وكيف تصف الأشياء بالألمانية",
    category: "مفردات", duration: "15 دقيقة",
    content: {
      intro: "الألوان مهمة لوصف الأشياء من حولك. هيا نتعلمها!",
      vocabulary: [
        { de: "rot", ar: "أحمر", example: "Das Auto ist rot." },
        { de: "blau", ar: "أزرق", example: "Der Himmel ist blau." },
        { de: "grün", ar: "أخضر", example: "Das Gras ist grün." },
        { de: "gelb", ar: "أصفر", example: "Die Sonne ist gelb." },
        { de: "schwarz", ar: "أسود", example: "Die Katze ist schwarz." },
        { de: "weiß", ar: "أبيض", example: "Der Schnee ist weiß." },
        { de: "grau", ar: "رمادي", example: "Der Elefant ist grau." },
        { de: "braun", ar: "بني", example: "Der Tisch ist braun." },
        { de: "orange", ar: "برتقالي", example: "Die Orange ist orange." },
        { de: "lila / violett", ar: "بنفسجي", example: "Die Blume ist lila." },
      ],
      grammar: [
        { rule: "الصفة تتغير حسب جنس الاسم", example: "ein rotes Auto / eine rote Blume", translation: "سيارة حمراء / زهرة حمراء" },
      ],
      tips: [
        "في الجملة البسيطة: Das Haus ist blau (البيت أزرق)",
        "قبل الاسم تتصرف الألوان كصفات وتأخذ لاحقات",
      ],
    },
  },
  {
    id: 4, title: "أفراد العائلة", titleDe: "Die Familie",
    description: "تعرف على مفردات العائلة وكيف تتحدث عن أهلك",
    category: "مفردات", duration: "20 دقيقة",
    content: {
      intro: "العائلة من أهم المواضيع للتواصل. ستتعلم هنا كيف تتحدث عن عائلتك.",
      vocabulary: [
        { de: "die Mutter / die Mama", ar: "الأم / ماما", example: "Meine Mutter heißt Fatima." },
        { de: "der Vater / der Papa", ar: "الأب / بابا", example: "Mein Vater arbeitet in Casablanca." },
        { de: "der Bruder", ar: "الأخ", example: "Ich habe zwei Brüder." },
        { de: "die Schwester", ar: "الأخت", example: "Meine Schwester ist 15 Jahre alt." },
        { de: "die Großmutter / die Oma", ar: "الجدة", example: "Meine Oma wohnt in Marrakesch." },
        { de: "der Großvater / der Opa", ar: "الجد", example: "Mein Opa ist 70 Jahre alt." },
        { de: "der Onkel", ar: "العم / الخال", example: "Mein Onkel wohnt in Deutschland." },
        { de: "die Tante", ar: "العمة / الخالة", example: "Meine Tante hat drei Kinder." },
        { de: "der Cousin / die Cousine", ar: "ابن العم / بنت العم", example: "Mein Cousin studiert in Wien." },
        { de: "das Kind / die Kinder", ar: "الطفل / الأطفال", example: "Ich habe keine Kinder." },
      ],
      dialogue: [
        { speaker: "يوسف", de: "Hast du Geschwister?", ar: "هل لديك إخوة وأخوات؟" },
        { speaker: "لميا", de: "Ja, ich habe einen Bruder und zwei Schwestern.", ar: "نعم، لدي أخ وأختان." },
        { speaker: "يوسف", de: "Wie alt sind sie?", ar: "كم أعمارهم؟" },
        { speaker: "لميا", de: "Mein Bruder ist 20 und meine Schwestern sind 16 und 14.", ar: "أخي عمره 20 وأختاي 16 و14." },
      ],
      tips: [
        "في الألمانية: mein (مذكر) / meine (مؤنث) = بتاعي / ملكي",
        "Ich habe... = عندي / لدي",
      ],
    },
  },
  {
    id: 5, title: "اليوم والوقت", titleDe: "Uhrzeit und Tageszeiten",
    description: "تعلم كيف تسأل عن الوقت وتقرأ الساعة بالألمانية",
    category: "أساسيات", duration: "25 دقيقة",
    content: {
      intro: "معرفة الوقت ضرورية في الحياة اليومية — للمواعيد والقطارات والدراسة.",
      vocabulary: [
        { de: "Wie spät ist es?", ar: "كم الساعة الآن؟" },
        { de: "Es ist ein Uhr.", ar: "الساعة الواحدة." },
        { de: "Es ist halb drei.", ar: "الساعة الثانية والنصف." },
        { de: "Es ist Viertel nach vier.", ar: "الساعة الرابعة والربع." },
        { de: "Es ist Viertel vor fünf.", ar: "الساعة الخامسة إلا ربع." },
        { de: "der Morgen", ar: "الصباح" },
        { de: "der Mittag", ar: "الظهر" },
        { de: "der Nachmittag", ar: "بعد الظهر" },
        { de: "der Abend", ar: "المساء" },
        { de: "die Nacht", ar: "الليل" },
      ],
      grammar: [
        { rule: "للتعبير عن الوقت الرسمي نستخدم الأرقام", example: "Der Zug fährt um 14:30 Uhr ab.", translation: "القطار يغادر الساعة 2:30 ظهراً." },
      ],
      tips: [
        "'halb' تعني النصف وتشير إلى الساعة القادمة: halb drei = 2:30",
        "'Viertel nach' = والربع، 'Viertel vor' = إلا ربع",
      ],
    },
  },
  {
    id: 6, title: "أيام الأسبوع والشهور", titleDe: "Wochentage und Monate",
    description: "تعلم أسماء أيام الأسبوع والشهور والمواسم",
    category: "أساسيات", duration: "20 دقيقة",
    content: {
      intro: "أيام الأسبوع والشهور أساسية للحديث عن المواعيد والخطط.",
      vocabulary: [
        { de: "Montag", ar: "الاثنين" }, { de: "Dienstag", ar: "الثلاثاء" },
        { de: "Mittwoch", ar: "الأربعاء" }, { de: "Donnerstag", ar: "الخميس" },
        { de: "Freitag", ar: "الجمعة" }, { de: "Samstag", ar: "السبت" },
        { de: "Sonntag", ar: "الأحد" }, { de: "Januar", ar: "يناير" },
        { de: "Februar", ar: "فبراير" }, { de: "März", ar: "مارس" },
        { de: "April", ar: "أبريل" }, { de: "Mai", ar: "مايو" },
        { de: "Juni", ar: "يونيو" }, { de: "Juli", ar: "يوليو" },
        { de: "August", ar: "أغسطس" }, { de: "September", ar: "سبتمبر" },
        { de: "Oktober", ar: "أكتوبر" }, { de: "November", ar: "نوفمبر" },
        { de: "Dezember", ar: "ديسمبر" },
      ],
      tips: [
        "الأيام والشهور مذكرة في الألمانية: der Montag، der Januar",
        "am + يوم = في يوم: am Montag = يوم الاثنين",
        "im + شهر = في شهر: im Januar = في يناير",
      ],
    },
  },
  {
    id: 7, title: "الضمائر الشخصية وفعل Sein", titleDe: "Personalpronomen und sein",
    description: "تعلم الضمائر الشخصية وتصريف فعل 'كان / يكون'",
    category: "قواعد", duration: "30 دقيقة",
    content: {
      intro: "الضمائر الشخصية وفعل 'sein' هما أساس كل جملة ألمانية.",
      vocabulary: [
        { de: "ich", ar: "أنا" }, { de: "du", ar: "أنت (غير رسمي)" },
        { de: "er", ar: "هو" }, { de: "sie", ar: "هي / هم / أنت (رسمي)" },
        { de: "es", ar: "هو / هي (للأشياء المحايدة)" }, { de: "wir", ar: "نحن" },
        { de: "ihr", ar: "أنتم (غير رسمي)" }, { de: "Sie", ar: "أنت / أنتم (رسمي)" },
      ],
      grammar: [
        { rule: "ich bin", example: "Ich bin Student.", translation: "أنا طالب." },
        { rule: "du bist", example: "Du bist nett.", translation: "أنت لطيف." },
        { rule: "er/sie/es ist", example: "Er ist Arzt.", translation: "هو طبيب." },
        { rule: "wir sind", example: "Wir sind Freunde.", translation: "نحن أصدقاء." },
        { rule: "ihr seid", example: "Ihr seid müde.", translation: "أنتم متعبون." },
        { rule: "sie/Sie sind", example: "Sie sind Lehrer.", translation: "هم / أنت (رسمي) مدرس." },
      ],
      tips: [
        "'Sie' بحرف كبير = الصيغة الرسمية لـ 'أنت'",
        "'sie' بحرف صغير = هي أو هم",
      ],
    },
  },
  {
    id: 8, title: "الأطعمة والمشروبات", titleDe: "Essen und Trinken",
    description: "تعلم مفردات الطعام والشراب وكيف تطلب في المطعم",
    category: "حياة يومية", duration: "25 دقيقة",
    content: {
      intro: "الطعام موضوع ممتع ومهم. تعلم كيف تتحدث عما تحب وتكره.",
      vocabulary: [
        { de: "das Brot", ar: "الخبز", example: "Ich esse gern Brot." },
        { de: "die Milch", ar: "الحليب", example: "Ich trinke Milch zum Frühstück." },
        { de: "der Käse", ar: "الجبن", example: "Möchten Sie Käse?" },
        { de: "das Fleisch", ar: "اللحم", example: "Ich esse kein Schweinefleisch." },
        { de: "der Fisch", ar: "السمك", example: "Fisch ist gesund." },
        { de: "das Gemüse", ar: "الخضروات", example: "Ich mag Gemüse." },
        { de: "das Obst", ar: "الفاكهة", example: "Obst ist lecker." },
        { de: "der Kaffee", ar: "القهوة", example: "Ich trinke jeden Morgen Kaffee." },
        { de: "der Tee", ar: "الشاي", example: "In Marokko trinkt man viel Tee." },
        { de: "das Wasser", ar: "الماء", example: "Ein Glas Wasser, bitte." },
      ],
      dialogue: [
        { speaker: "نادل", de: "Was möchten Sie trinken?", ar: "ماذا تريد أن تشرب؟" },
        { speaker: "عميل", de: "Ich möchte einen Kaffee und ein Glas Wasser, bitte.", ar: "أريد قهوة وكأس ماء، من فضلك." },
        { speaker: "نادل", de: "Und was essen Sie?", ar: "وماذا ستأكل؟" },
        { speaker: "عميل", de: "Ich nehme das Tagesmenü.", ar: "سآخذ طبق اليوم." },
      ],
      tips: [
        "ich esse gern = أحب أن آكل",
        "ich esse nicht gern = لا أحب أن آكل",
        "Ich möchte... = أريد... (للطلب بأدب)",
      ],
    },
  },
  {
    id: 9, title: "المهن والوظائف", titleDe: "Berufe",
    description: "تعلم أسماء المهن وكيف تتحدث عن عملك",
    category: "حياة يومية", duration: "20 دقيقة",
    content: {
      intro: "معرفة المهن مهمة لتعريف نفسك وفهم محيطك المهني.",
      vocabulary: [
        { de: "der Arzt / die Ärztin", ar: "الطبيب / الطبيبة", example: "Mein Vater ist Arzt." },
        { de: "der Lehrer / die Lehrerin", ar: "المعلم / المعلمة", example: "Ich bin Lehrerin." },
        { de: "der Ingenieur / die Ingenieurin", ar: "المهندس / المهندسة", example: "Er ist Ingenieur bei BMW." },
        { de: "der Student / die Studentin", ar: "الطالب / الطالبة", example: "Ich bin Student an der Universität Rabat." },
        { de: "der Krankenpfleger / die Krankenpflegerin", ar: "الممرض / الممرضة", example: "Sie ist Krankenpflegerin." },
        { de: "der Polizist / die Polizistin", ar: "الشرطي / الشرطية", example: "Der Polizist hilft uns." },
        { de: "der Koch / die Köchin", ar: "الطاهي / الطاهية", example: "Er ist Koch in einem Restaurant." },
        { de: "der Verkäufer / die Verkäuferin", ar: "البائع / البائعة", example: "Die Verkäuferin ist freundlich." },
        { de: "der Fahrer / die Fahrerin", ar: "السائق / السائقة", example: "Er ist Taxifahrer." },
        { de: "der Anwalt / die Anwältin", ar: "المحامي / المحامية", example: "Meine Schwester ist Anwältin." },
      ],
      grammar: [
        { rule: "في الألمانية: Ich bin + مهنة (بدون مقالة)", example: "Ich bin Lehrer. (وليس: Ich bin ein Lehrer)", translation: "أنا معلم." },
        { rule: "المؤنث: نضيف -in في الغالب", example: "Lehrer ➜ Lehrerin", translation: "معلم ➜ معلمة" },
      ],
      tips: [
        "لا تضع مقالة (ein/eine) بعد 'sein' عند ذكر المهنة",
        "الغالبية العظمى من المهن لها صيغة مؤنثة بإضافة '-in'",
      ],
    },
  },
  {
    id: 10, title: "الأماكن في المدينة", titleDe: "Orte in der Stadt",
    description: "تعرف على أسماء الأماكن المهمة في المدينة",
    category: "حياة يومية", duration: "20 دقيقة",
    content: {
      intro: "معرفة أسماء الأماكن ضرورية للتنقل وطلب المساعدة.",
      vocabulary: [
        { de: "der Bahnhof", ar: "محطة القطار", example: "Der Bahnhof ist in der Stadtmitte." },
        { de: "die Apotheke", ar: "الصيدلية", example: "Wo ist die nächste Apotheke?" },
        { de: "das Krankenhaus", ar: "المستشفى", example: "Das Krankenhaus ist um die Ecke." },
        { de: "die Schule", ar: "المدرسة", example: "Die Kinder gehen zur Schule." },
        { de: "die Universität", ar: "الجامعة", example: "Ich studiere an der Universität." },
        { de: "der Supermarkt", ar: "السوبرماركت", example: "Der Supermarkt ist geöffnet." },
        { de: "die Bank", ar: "البنك", example: "Ich muss zur Bank gehen." },
        { de: "das Hotel", ar: "الفندق", example: "Das Hotel ist sehr schön." },
        { de: "der Park", ar: "الحديقة العامة", example: "Kinder spielen im Park." },
        { de: "das Restaurant", ar: "المطعم", example: "Das Restaurant öffnet um 12 Uhr." },
      ],
      dialogue: [
        { speaker: "سائح", de: "Entschuldigung, wo ist der Bahnhof?", ar: "عفواً، أين محطة القطار؟" },
        { speaker: "مواطن", de: "Der Bahnhof ist geradeaus, dann links.", ar: "المحطة في الاتجاه المستقيم، ثم يساراً." },
        { speaker: "سائح", de: "Wie weit ist es?", ar: "كم المسافة؟" },
        { speaker: "مواطن", de: "Ungefähr 10 Minuten zu Fuß.", ar: "حوالي 10 دقائق مشياً." },
      ],
      tips: [
        "Wo ist...? = أين...؟",
        "Wie komme ich zu...? = كيف أصل إلى...؟",
      ],
    },
  },
  {
    id: 11, title: "صفات الأشخاص", titleDe: "Eigenschaften von Personen",
    description: "تعلم كيف تصف شخصيات الناس وصفاتهم",
    category: "مفردات", duration: "20 دقيقة",
    content: {
      intro: "وصف الناس مهارة مهمة في التواصل اليومي.",
      vocabulary: [
        { de: "groß / klein", ar: "طويل / قصير", example: "Er ist groß und sie ist klein." },
        { de: "jung / alt", ar: "شاب / كبير", example: "Meine Oma ist alt aber aktiv." },
        { de: "freundlich", ar: "ودود / لطيف", example: "Die Deutschen sind freundlich." },
        { de: "nett", ar: "طيب", example: "Er ist sehr nett." },
        { de: "klug / intelligent", ar: "ذكي", example: "Sie ist sehr intelligent." },
        { de: "fleißig", ar: "مجتهد", example: "Die Studenten sind fleißig." },
        { de: "lustig", ar: "مضحك / مرح", example: "Mein Bruder ist sehr lustig." },
        { de: "ruhig", ar: "هادئ", example: "Sie ist ruhig und geduldig." },
        { de: "schön", ar: "جميل", example: "Marrakesch ist eine schöne Stadt." },
        { de: "müde", ar: "متعب", example: "Ich bin heute sehr müde." },
      ],
      tips: [
        "يمكن نفي الصفة بـ 'nicht': Er ist nicht groß = هو ليس طويلاً",
        "sehr (جداً) تقوي الصفة: sehr freundlich = لطيف جداً",
      ],
    },
  },
  {
    id: 12, title: "الفعل 'haben'", titleDe: "Das Verb 'haben'",
    description: "تصريف فعل haben واستخدامه في جمل مفيدة",
    category: "قواعد", duration: "25 دقيقة",
    content: {
      intro: "فعل 'haben' (أن يملك / أن يكون عنده) من أهم الأفعال الألمانية.",
      vocabulary: [
        { de: "ich habe", ar: "أنا عندي / أملك", example: "Ich habe ein Auto." },
        { de: "du hast", ar: "أنت عندك", example: "Hast du ein Handy?" },
        { de: "er/sie/es hat", ar: "هو/هي عنده/ا", example: "Sie hat zwei Kinder." },
        { de: "wir haben", ar: "نحن عندنا", example: "Wir haben ein Problem." },
        { de: "ihr habt", ar: "أنتم عندكم", example: "Habt ihr Zeit?" },
        { de: "sie/Sie haben", ar: "هم/أنت(رسمي) عندهم", example: "Sie haben viel Erfahrung." },
      ],
      grammar: [
        { rule: "haben + مفعول به", example: "Ich habe Hunger. / Ich habe Durst.", translation: "أنا جائع. / أنا عطشان." },
        { rule: "النفي: kein/keine", example: "Ich habe keine Zeit.", translation: "ليس عندي وقت." },
      ],
      tips: [
        "Ich habe Hunger = أنا جائع",
        "Ich habe Durst = أنا عطشان",
        "Ich habe Angst = أنا خائف",
      ],
    },
  },
  {
    id: 13, title: "الجسم الإنساني", titleDe: "Der menschliche Körper",
    description: "تعلم أسماء أعضاء الجسم للحديث عن الصحة والطب",
    category: "مفردات", duration: "20 دقيقة",
    content: {
      intro: "معرفة أعضاء الجسم ضرورية خاصة عند زيارة الطبيب.",
      vocabulary: [
        { de: "der Kopf", ar: "الرأس", example: "Ich habe Kopfschmerzen." },
        { de: "das Auge / die Augen", ar: "العين / العيون", example: "Sie hat blaue Augen." },
        { de: "die Nase", ar: "الأنف", example: "Meine Nase tut weh." },
        { de: "der Mund", ar: "الفم", example: "Bitte öffnen Sie den Mund." },
        { de: "das Ohr / die Ohren", ar: "الأذن / الآذان", example: "Meine Ohren tun weh." },
        { de: "der Hals", ar: "الحلق / الرقبة", example: "Ich habe Halsschmerzen." },
        { de: "der Arm / die Arme", ar: "الذراع / الأذرع", example: "Mein Arm ist gebrochen." },
        { de: "die Hand / die Hände", ar: "اليد / الأيادي", example: "Bitte waschen Sie die Hände." },
        { de: "der Bauch", ar: "البطن", example: "Ich habe Bauchschmerzen." },
        { de: "das Bein / die Beine", ar: "الساق / الساقان", example: "Mein Bein tut weh." },
      ],
      tips: [
        "-schmerzen = ألم: Kopfschmerzen (صداع)، Bauchschmerzen (ألم بطن)",
        "Ich habe Schmerzen in... = عندي ألم في...",
        "Wo tut es weh? = أين يؤلمك؟",
      ],
    },
  },
  {
    id: 14, title: "الحيوانات", titleDe: "Haustiere und wilde Tiere",
    description: "تعلم أسماء الحيوانات الشائعة بالألمانية",
    category: "مفردات", duration: "15 دقيقة",
    content: {
      intro: "الحيوانات موضوع محبوب لدى الجميع. هيا نتعلم أسماءها!",
      vocabulary: [
        { de: "der Hund", ar: "الكلب", example: "Ich habe einen Hund." },
        { de: "die Katze", ar: "القطة", example: "Die Katze schläft." },
        { de: "das Pferd", ar: "الحصان", example: "Das Pferd ist schnell." },
        { de: "der Löwe", ar: "الأسد", example: "Der Löwe ist der König der Tiere." },
        { de: "der Elefant", ar: "الفيل", example: "Elefanten haben gutes Gedächtnis." },
        { de: "der Vogel", ar: "الطائر", example: "Der Vogel singt schön." },
        { de: "der Fisch", ar: "السمكة", example: "Fische leben im Wasser." },
        { de: "die Schlange", ar: "الثعبان", example: "Schlangen sind gefährlich." },
        { de: "das Kamel", ar: "الجمل", example: "In der Sahara gibt es Kamele." },
        { de: "der Affe", ar: "القرد", example: "Affen sind intelligent." },
      ],
      tips: [
        "Ich mag Hunde. = أحب الكلاب",
        "Ich habe Angst vor Schlangen. = أخاف من الثعابين",
      ],
    },
  },
  {
    id: 15, title: "الطقس والمناخ", titleDe: "Das Wetter",
    description: "تحدث عن الطقس وتوقعاته بالألمانية",
    category: "حياة يومية", duration: "20 دقيقة",
    content: {
      intro: "الطقس موضوع التحادث الأول في ألمانيا! تعلمه لتبدأ محادثاتك.",
      vocabulary: [
        { de: "Es ist sonnig.", ar: "الجو مشمس.", example: "Heute ist es sonnig und warm." },
        { de: "Es regnet.", ar: "تمطر.", example: "Es regnet heute. Nimm einen Schirm." },
        { de: "Es schneit.", ar: "تثلج.", example: "Im Winter schneit es in Deutschland." },
        { de: "Es ist bewölkt.", ar: "الجو غائم.", example: "Es ist bewölkt aber warm." },
        { de: "Es ist windig.", ar: "الجو عاصف.", example: "Es ist sehr windig heute." },
        { de: "Es ist heiß.", ar: "الجو حار.", example: "Im Sommer ist es sehr heiß." },
        { de: "Es ist kalt.", ar: "الجو بارد.", example: "Im Winter ist es sehr kalt." },
        { de: "der Frühling", ar: "الربيع", example: "Im Frühling blühen die Blumen." },
        { de: "der Sommer", ar: "الصيف", example: "Im Sommer fahren wir ans Meer." },
        { de: "der Herbst", ar: "الخريف", example: "Im Herbst fallen die Blätter." },
        { de: "der Winter", ar: "الشتاء", example: "Im Winter ist es kalt." },
      ],
      tips: [
        "Wie ist das Wetter heute? = كيف الطقس اليوم؟",
        "Was ist die Temperatur? = كم درجة الحرارة؟",
        "في ألمانيا الحديث عن الطقس = الموضوع الاجتماعي الأول!",
      ],
    },
  },
];

const a2Lessons: Lesson[] = [
  {
    id: 1, title: "في السوبرماركت", titleDe: "Im Supermarkt",
    description: "تعلم كيف تتسوق وتسأل عن الأسعار وتطلب المساعدة",
    category: "حياة يومية", duration: "25 دقيقة",
    content: {
      intro: "التسوق مهارة يومية أساسية. ستتعلم هنا كيف تتعامل في السوبرماركت.",
      vocabulary: [
        { de: "Was kostet das?", ar: "كم يكلف هذا؟", example: "Was kostet dieses Hemd?" },
        { de: "Wie viel kostet...?", ar: "بكم...؟", example: "Wie viel kostet ein Kilo Tomaten?" },
        { de: "das kostet...", ar: "يكلف...", example: "Das kostet drei Euro." },
        { de: "günstig / billig", ar: "رخيص", example: "Das ist sehr günstig!" },
        { de: "teuer", ar: "غالي", example: "Das ist zu teuer für mich." },
        { de: "die Kasse", ar: "الصندوق / الكاشير", example: "Bitte zahlen Sie an der Kasse." },
        { de: "der Einkaufswagen", ar: "عربة التسوق", example: "Ich brauche einen Einkaufswagen." },
        { de: "die Tüte", ar: "الكيس", example: "Brauchen Sie eine Tüte?" },
        { de: "das Angebot", ar: "العرض / التخفيض", example: "Milch ist heute im Angebot." },
        { de: "der Rabatt", ar: "الخصم", example: "Gibt es einen Rabatt?" },
      ],
      dialogue: [
        { speaker: "بائع", de: "Kann ich Ihnen helfen?", ar: "هل يمكنني مساعدتك؟" },
        { speaker: "مشتري", de: "Ja, wo finde ich die Milch?", ar: "نعم، أين أجد الحليب؟" },
        { speaker: "بائع", de: "Die Milch ist in Gang 3, links.", ar: "الحليب في الممر 3، على اليسار." },
        { speaker: "مشتري", de: "Danke. Und was kostet ein Liter?", ar: "شكراً. وبكم اللتر؟" },
        { speaker: "بائع", de: "Ein Liter kostet 1,20 Euro.", ar: "اللتر بـ 1.20 يورو." },
      ],
      tips: [
        "الأسعار تُقرأ: 3,50 EUR = drei Euro fünfzig",
        "Ich möchte... = أريد... (للطلب بأدب)",
        "Haben Sie...? = هل عندكم...؟",
      ],
    },
  },
  {
    id: 2, title: "المواصلات والتنقل", titleDe: "Verkehrsmittel und Transport",
    description: "تعلم كيف تستخدم وسائل النقل وتشتري تذاكر",
    category: "حياة يومية", duration: "30 دقيقة",
    content: {
      intro: "التنقل في ألمانيا سهل مع شبكة مواصلات ممتازة. تعلم كيف تستخدمها!",
      vocabulary: [
        { de: "der Zug", ar: "القطار", example: "Der Zug fährt um 9 Uhr ab." },
        { de: "die U-Bahn", ar: "المترو", example: "Ich nehme die U-Bahn zur Arbeit." },
        { de: "der Bus", ar: "الحافلة", example: "Welcher Bus fährt zum Flughafen?" },
        { de: "das Taxi", ar: "سيارة الأجرة", example: "Ich brauche ein Taxi." },
        { de: "das Fahrrad", ar: "الدراجة", example: "Ich fahre mit dem Fahrrad." },
        { de: "der Flughafen", ar: "المطار", example: "Der Flughafen ist weit weg." },
        { de: "die Fahrkarte / das Ticket", ar: "التذكرة", example: "Ich möchte eine Fahrkarte nach München." },
        { de: "der Bahnsteig", ar: "الرصيف", example: "Der Zug fährt auf Gleis 5." },
        { de: "pünktlich", ar: "في الوقت المحدد", example: "Der Zug ist pünktlich." },
        { de: "Verspätung", ar: "التأخير", example: "Der Zug hat 10 Minuten Verspätung." },
      ],
      dialogue: [
        { speaker: "عميل", de: "Eine Fahrkarte nach Berlin, bitte.", ar: "تذكرة إلى برلين، من فضلك." },
        { speaker: "موظف", de: "Einfach oder hin und zurück?", ar: "ذهاب فقط أم ذهاب وإياب؟" },
        { speaker: "عميل", de: "Hin und zurück. Wann fährt der nächste Zug?", ar: "ذهاب وإياب. متى ينطلق القطار القادم؟" },
        { speaker: "موظف", de: "Um 14:32 Uhr auf Gleis 7.", ar: "الساعة 14:32 على الرصيف 7." },
      ],
      tips: [
        "Deutsche Bahn (DB) = شبكة القطارات الألمانية",
        "Einfach = ذهاب فقط — Hin und zurück = ذهاب وإياب",
        "يمكن شراء التذاكر من التطبيق أو الآلة الأوتوماتيكية",
      ],
    },
  },
  {
    id: 3, title: "الاتجاهات والأماكن", titleDe: "Richtungen und Wegbeschreibung",
    description: "تعلم كيف تطلب وتعطي الاتجاهات",
    category: "حياة يومية", duration: "25 دقيقة",
    content: {
      intro: "القدرة على طلب وإعطاء الاتجاهات ضرورية جداً.",
      vocabulary: [
        { de: "geradeaus", ar: "إلى الأمام / مستقيم", example: "Gehen Sie geradeaus." },
        { de: "links", ar: "يساراً", example: "Biegen Sie links ab." },
        { de: "rechts", ar: "يميناً", example: "Das Krankenhaus ist rechts." },
        { de: "die Kreuzung", ar: "التقاطع", example: "An der Kreuzung biegen Sie rechts ab." },
        { de: "die Ampel", ar: "إشارة المرور", example: "Bei der Ampel links abbiegen." },
        { de: "gegenüber", ar: "في مواجهة / أمام", example: "Die Post ist gegenüber dem Bahnhof." },
        { de: "neben", ar: "بجانب", example: "Das Hotel ist neben dem Park." },
        { de: "hinter", ar: "خلف", example: "Das Auto steht hinter dem Haus." },
        { de: "vor", ar: "أمام", example: "Wir treffen uns vor dem Kino." },
        { de: "zwischen", ar: "بين", example: "Die Bank ist zwischen dem Supermarkt und der Apotheke." },
      ],
      dialogue: [
        { speaker: "سائح", de: "Entschuldigung! Wo ist das Museum?", ar: "عفواً! أين المتحف؟" },
        { speaker: "مواطن", de: "Gehen Sie geradeaus bis zur Kreuzung, dann rechts.", ar: "اذهب مستقيماً حتى التقاطع، ثم يميناً." },
        { speaker: "سائح", de: "Ist es weit?", ar: "هل هو بعيد؟" },
        { speaker: "مواطن", de: "Nein, nur 5 Minuten zu Fuß.", ar: "لا، فقط 5 دقائق مشياً." },
      ],
      tips: [
        "Entschuldigung = عفواً / معليش (لجلب الانتباه)",
        "Wie komme ich zu...? = كيف أصل إلى...؟",
        "Können Sie mir helfen? = هل يمكنك مساعدتي؟",
      ],
    },
  },
  {
    id: 4, title: "في المطعم", titleDe: "Im Restaurant",
    description: "تعلم كيف تطلب الطعام وتتعامل في المطاعم",
    category: "حياة يومية", duration: "25 دقيقة",
    content: {
      intro: "زيارة المطعم تجربة اجتماعية مهمة. تعلم كيف تتصرف وتطلب!",
      vocabulary: [
        { de: "die Speisekarte", ar: "قائمة الطعام", example: "Kann ich die Speisekarte sehen?" },
        { de: "die Vorspeise", ar: "المقبلات", example: "Als Vorspeise nehme ich die Suppe." },
        { de: "das Hauptgericht", ar: "الطبق الرئيسي", example: "Als Hauptgericht möchte ich das Steak." },
        { de: "die Nachspeise / der Nachtisch", ar: "الحلوى", example: "Als Nachtisch hätte ich gern Eis." },
        { de: "die Rechnung", ar: "الفاتورة", example: "Die Rechnung, bitte!" },
        { de: "das Trinkgeld", ar: "البقشيش", example: "In Deutschland gibt man Trinkgeld." },
        { de: "allergisch", ar: "حساسية", example: "Ich bin allergisch gegen Nüsse." },
        { de: "vegetarisch", ar: "نباتي", example: "Haben Sie vegetarische Gerichte?" },
        { de: "lecker", ar: "لذيذ", example: "Das Essen war sehr lecker!" },
        { de: "bestellen", ar: "يطلب", example: "Wir möchten bitte bestellen." },
      ],
      dialogue: [
        { speaker: "نادل", de: "Haben Sie schon gewählt?", ar: "هل اخترتم بالفعل؟" },
        { speaker: "عميل", de: "Ja. Ich nehme das Hähnchen mit Salat.", ar: "نعم. سآخذ الدجاج مع السلطة." },
        { speaker: "نادل", de: "Und was möchten Sie trinken?", ar: "وماذا تريد أن تشرب؟" },
        { speaker: "عميل", de: "Ein Mineralwasser, bitte. Und am Ende die Rechnung.", ar: "مياه معدنية، من فضلك. وفي النهاية الفاتورة." },
      ],
      tips: [
        "في ألمانيا البقشيش عادةً 10% من الفاتورة",
        "Getrennt oder zusammen? = منفصلين أم معاً؟ (عند الدفع)",
        "Das war sehr lecker! = كان لذيذاً جداً!",
      ],
    },
  },
  {
    id: 5, title: "الزمن الماضي — Perfekt", titleDe: "Das Perfekt",
    description: "تعلم كيف تتحدث عن أحداث في الماضي",
    category: "قواعد", duration: "35 دقيقة",
    content: {
      intro: "الزمن الماضي (Perfekt) هو الأكثر استخداماً في الحديث اليومي.",
      vocabulary: [
        { de: "ich habe gegessen", ar: "أكلت", example: "Ich habe Pizza gegessen." },
        { de: "ich habe getrunken", ar: "شربت", example: "Ich habe Kaffee getrunken." },
        { de: "ich bin gegangen", ar: "ذهبت", example: "Ich bin ins Kino gegangen." },
        { de: "ich habe geschlafen", ar: "نمت", example: "Ich habe gut geschlafen." },
        { de: "ich habe gemacht", ar: "فعلت", example: "Ich habe Hausaufgaben gemacht." },
        { de: "ich bin gefahren", ar: "سافرت / ركبت", example: "Ich bin nach Berlin gefahren." },
        { de: "ich habe gesehen", ar: "رأيت", example: "Ich habe einen Film gesehen." },
        { de: "ich habe gelesen", ar: "قرأت", example: "Ich habe ein Buch gelesen." },
      ],
      grammar: [
        { rule: "Perfekt = haben/sein + Partizip II", example: "Ich habe das Buch gelesen.", translation: "قرأت الكتاب." },
        { rule: "أفعال الحركة + sein", example: "Ich bin nach München gefahren.", translation: "ذهبت إلى ميونيخ." },
        { rule: "باقي الأفعال + haben", example: "Er hat Fußball gespielt.", translation: "لعب كرة القدم." },
      ],
      tips: [
        "Partizip II للأفعال المنتظمة: ge- + Stamm + -t",
        "Partizip II للأفعال غير المنتظمة: يجب حفظها",
        "أفعال الحركة تستخدم 'sein': fahren، gehen، kommen",
      ],
    },
  },
  {
    id: 6, title: "التسوق للملابس", titleDe: "Kleidung kaufen",
    description: "تعلم مفردات الملابس وكيف تتسوق لها",
    category: "حياة يومية", duration: "25 دقيقة",
    content: {
      intro: "الملابس موضوع شيق. تعلم كيف تصف ما تلبس وكيف تتسوق.",
      vocabulary: [
        { de: "das Hemd", ar: "القميص (رجالي)", example: "Das blaue Hemd gefällt mir." },
        { de: "die Bluse", ar: "البلوزة (نسائية)", example: "Diese Bluse ist sehr schön." },
        { de: "die Hose", ar: "البنطال", example: "Ich suche eine schwarze Hose." },
        { de: "der Rock", ar: "التنورة", example: "Der Rock ist zu kurz." },
        { de: "das Kleid", ar: "الفستان", example: "Das rote Kleid ist elegant." },
        { de: "der Mantel", ar: "المعطف", example: "Im Winter brauche ich einen warmen Mantel." },
        { de: "die Jacke", ar: "الجاكيت", example: "Diese Jacke ist praktisch." },
        { de: "die Schuhe (Pl.)", ar: "الأحذية", example: "Ich brauche neue Schuhe." },
        { de: "die Größe", ar: "المقاس", example: "Welche Größe haben Sie?" },
        { de: "anprobieren", ar: "يجرب (يقيس)", example: "Kann ich das anprobieren?" },
      ],
      dialogue: [
        { speaker: "بائع", de: "Kann ich Ihnen helfen?", ar: "هل يمكنني مساعدتك؟" },
        { speaker: "عميل", de: "Ja, ich suche eine Jacke. Haben Sie etwas in Größe M?", ar: "نعم، أبحث عن جاكيت. هل عندكم مقاس M؟" },
        { speaker: "بائع", de: "Ja, die hier. Möchten Sie sie anprobieren?", ar: "نعم، هذه هنا. هل تريد تجربتها؟" },
        { speaker: "عميل", de: "Ja, bitte. Die steht mir gut! Wie viel kostet sie?", ar: "نعم، من فضلك. تبدو عليّ جيدة! كم سعرها؟" },
      ],
      tips: [
        "Das passt mir. = تناسبني.",
        "Das steht mir gut. = تبدو عليّ جيدة.",
        "Zu groß / zu klein / zu lang / zu kurz = كبيرة / صغيرة / طويلة / قصيرة جداً",
      ],
    },
  },
  {
    id: 7, title: "الحياة اليومية والروتين", titleDe: "Alltag und Tagesablauf",
    description: "تعلم كيف تصف يومك وروتينك اليومي",
    category: "حياة يومية", duration: "25 دقيقة",
    content: {
      intro: "وصف الروتين اليومي مهارة أساسية للتحدث عن حياتك.",
      vocabulary: [
        { de: "aufstehen", ar: "يستيقظ / ينهض", example: "Ich stehe um 7 Uhr auf." },
        { de: "frühstücken", ar: "يتناول الإفطار", example: "Ich frühstücke um halb acht." },
        { de: "zur Arbeit / Schule gehen", ar: "يذهب للعمل / المدرسة", example: "Ich gehe um 8 Uhr zur Arbeit." },
        { de: "zu Mittag essen", ar: "يتناول الغداء", example: "Ich esse zu Mittag um 13 Uhr." },
        { de: "nach Hause kommen", ar: "يعود للبيت", example: "Ich komme um 18 Uhr nach Hause." },
        { de: "kochen", ar: "يطبخ", example: "Ich koche das Abendessen." },
        { de: "fernsehen", ar: "يشاهد التلفاز", example: "Ich sehe abends fern." },
        { de: "schlafen gehen", ar: "يذهب للنوم", example: "Ich gehe um 23 Uhr schlafen." },
        { de: "sich waschen", ar: "يغتسل", example: "Ich wasche mich morgens." },
        { de: "sich anziehen", ar: "يرتدي ملابسه", example: "Ich ziehe mich schnell an." },
      ],
      grammar: [
        { rule: "الأفعال المنفصلة تنفصل في الجملة", example: "Ich stehe um 7 Uhr auf.", translation: "أنا أستيقظ الساعة 7." },
      ],
      tips: [
        "الأفعال المنفصلة (trennbare Verben) تضع البادئة في نهاية الجملة",
        "aufstehen: Ich stehe auf (وليس: Ich aufstehe)",
        "Wann stehst du auf? = متى تستيقظ؟",
      ],
    },
  },
  {
    id: 8, title: "المواعيد والتخطيط", titleDe: "Termine und Verabredungen",
    description: "تعلم كيف ترتب المواعيد وتخطط للأنشطة",
    category: "تواصل", duration: "25 دقيقة",
    content: {
      intro: "الألمان يحبون الدقة والتخطيط. تعلم كيف تحجز مواعيد وترتب لقاءات.",
      vocabulary: [
        { de: "der Termin", ar: "الموعد", example: "Ich habe einen Termin beim Arzt." },
        { de: "die Verabredung", ar: "الموعد / اللقاء", example: "Haben wir eine Verabredung?" },
        { de: "vereinbaren", ar: "يرتب / يتفق على", example: "Können wir einen Termin vereinbaren?" },
        { de: "absagen", ar: "يلغي", example: "Ich muss den Termin leider absagen." },
        { de: "verschieben", ar: "يؤجل", example: "Können wir den Termin verschieben?" },
        { de: "pünktlich sein", ar: "يكون في الوقت", example: "Bitte seien Sie pünktlich." },
        { de: "sich treffen", ar: "يلتقي", example: "Wir treffen uns um 15 Uhr." },
        { de: "Passt es Ihnen?", ar: "هل يناسبك؟", example: "Passt es Ihnen am Dienstag?" },
      ],
      dialogue: [
        { speaker: "مريض", de: "Guten Tag, ich möchte einen Termin beim Doktor.", ar: "مرحباً، أريد موعداً عند الطبيب." },
        { speaker: "موظف", de: "Wann passt es Ihnen?", ar: "متى يناسبك؟" },
        { speaker: "مريض", de: "Am Donnerstag, wenn möglich.", ar: "يوم الخميس، إن أمكن." },
        { speaker: "موظف", de: "Donnerstag um 10:30 Uhr?", ar: "الخميس الساعة 10:30؟" },
        { speaker: "مريض", de: "Ja, perfekt. Danke!", ar: "نعم، ممتاز. شكراً!" },
      ],
      tips: [
        "الألمان دقيقون جداً في المواعيد — التأخير غير مقبول",
        "إذا تأخرت أو ألغيت: أبلغ مسبقاً وقدم اعتذاراً",
        "Ich entschuldige mich für die Verspätung. = أعتذر عن التأخير.",
      ],
    },
  },
  {
    id: 9, title: "الصفات المقارنة", titleDe: "Komparativ und Superlativ",
    description: "تعلم كيف تقارن بين الأشياء والأشخاص",
    category: "قواعد", duration: "30 دقيقة",
    content: {
      intro: "المقارنة مهارة مهمة للتعبير عن رأيك وتفضيلاتك.",
      vocabulary: [
        { de: "groß — größer — am größten", ar: "كبير — أكبر — الأكبر", example: "Berlin ist größer als München." },
        { de: "klein — kleiner — am kleinsten", ar: "صغير — أصغر — الأصغر", example: "Das ist das kleinste Zimmer." },
        { de: "schnell — schneller — am schnellsten", ar: "سريع — أسرع — الأسرع", example: "Das ICE ist schneller als der Bus." },
        { de: "gut — besser — am besten", ar: "جيد — أفضل — الأفضل", example: "Dein Deutsch ist besser als meins." },
        { de: "viel — mehr — am meisten", ar: "كثير — أكثر — الأكثر", example: "Er hat mehr Zeit als ich." },
        { de: "teuer — teurer — am teuersten", ar: "غالي — أغلى — الأغلى", example: "Das Hotel ist am teuersten." },
      ],
      grammar: [
        { rule: "المقارنة: Adjektiv + -er + als", example: "München ist schöner als Berlin.", translation: "ميونيخ أجمل من برلين." },
        { rule: "التفضيل: am + Adjektiv + -sten", example: "Das ist am billigsten.", translation: "هذا الأرخص." },
      ],
      tips: [
        "gut ➜ besser ➜ am besten (شاذ)",
        "viel ➜ mehr ➜ am meisten (شاذ)",
        "gern ➜ lieber ➜ am liebsten (شاذ) للتفضيل",
      ],
    },
  },
  {
    id: 10, title: "التعليم والدراسة", titleDe: "Bildung und Schule",
    description: "تعلم مفردات المدرسة والجامعة والتعليم",
    category: "تعليم", duration: "25 دقيقة",
    content: {
      intro: "موضوع التعليم مهم خاصة إذا كنت تدرس في ألمانيا أو تريد إرسال أطفالك للمدرسة.",
      vocabulary: [
        { de: "die Grundschule", ar: "المدرسة الابتدائية", example: "Kinder gehen 4 Jahre in die Grundschule." },
        { de: "das Gymnasium", ar: "الثانوية العليا", example: "Das Gymnasium dauert bis zur 12. Klasse." },
        { de: "die Universität / die Uni", ar: "الجامعة", example: "Ich studiere an der Uni München." },
        { de: "das Studium", ar: "الدراسة الجامعية", example: "Mein Studium dauert 4 Jahre." },
        { de: "der Abschluss", ar: "الشهادة / التخرج", example: "Ich mache bald meinen Abschluss." },
        { de: "die Prüfung / der Test", ar: "الامتحان", example: "Ich lerne für die Prüfung." },
        { de: "bestehen / durchfallen", ar: "ينجح / يرسب", example: "Ich hoffe, ich bestehe die Prüfung." },
        { de: "das Fach", ar: "المادة الدراسية", example: "Mein Lieblingsfach ist Mathematik." },
        { de: "der Professor / die Professorin", ar: "الأستاذ الجامعي", example: "Professor Müller ist sehr streng." },
        { de: "die Note", ar: "الدرجة / العلامة", example: "Ich habe eine gute Note bekommen." },
      ],
      tips: [
        "في ألمانيا: 1 = ممتاز، 6 = راسب (عكس المغرب!)",
        "Numerus clausus (NC) = معدل القبول الجامعي",
        "Das Abitur = البكالوريا الألمانية",
      ],
    },
  },
  {
    id: 11, title: "الصحة والطبيب", titleDe: "Gesundheit und Arztbesuch",
    description: "تعلم كيف تصف أعراضك وتزور الطبيب",
    category: "صحة", duration: "30 دقيقة",
    content: {
      intro: "الصحة أهم شيء. تعلم كيف تتواصل مع الطبيب وتصف ألمك.",
      vocabulary: [
        { de: "krank sein", ar: "يكون مريضاً", example: "Ich bin krank. Ich brauche einen Arzt." },
        { de: "die Erkältung", ar: "نزلة البرد", example: "Ich habe eine Erkältung." },
        { de: "das Fieber", ar: "الحمى", example: "Ich habe hohes Fieber." },
        { de: "husten", ar: "يسعل", example: "Ich huste seit drei Tagen." },
        { de: "niesen", ar: "يعطس", example: "Ich niese ständig." },
        { de: "das Rezept", ar: "الوصفة الطبية", example: "Der Arzt hat mir ein Rezept gegeben." },
        { de: "die Medizin / das Medikament", ar: "الدواء", example: "Ich nehme zweimal täglich die Medizin." },
        { de: "die Krankenversicherung", ar: "التأمين الصحي", example: "Haben Sie eine Krankenversicherung?" },
        { de: "sich besser fühlen", ar: "يتحسن", example: "Ich fühle mich schon besser." },
        { de: "Gute Besserung!", ar: "شفاءً عاجلاً!", example: "Ich wünsche Ihnen gute Besserung!" },
      ],
      dialogue: [
        { speaker: "طبيب", de: "Was fehlt Ihnen?", ar: "ما الذي تشكو منه؟" },
        { speaker: "مريض", de: "Ich habe Halsschmerzen und Fieber seit gestern.", ar: "عندي ألم في الحلق وحمى منذ أمس." },
        { speaker: "طبيب", de: "Öffnen Sie bitte den Mund. Ich schaue nach.", ar: "افتح فمك من فضلك. سأفحص." },
        { speaker: "طبيب", de: "Sie haben eine Erkältung. Ich schreibe Ihnen ein Rezept.", ar: "عندك نزلة برد. سأكتب لك وصفة." },
      ],
      tips: [
        "Gute Besserung! = شفاءً عاجلاً!",
        "Ich fühle mich nicht gut. = لا أشعر بحال جيدة.",
        "Seit wann...? = منذ متى...؟",
      ],
    },
  },
];

const b1Lessons: Lesson[] = [
  {
    id: 1, title: "البحث عن عمل", titleDe: "Arbeit suchen",
    description: "تعلم كيف تكتب سيرة ذاتية وتتقدم لوظيفة",
    category: "عمل", duration: "35 دقيقة",
    content: {
      intro: "سوق العمل الألماني واسع للمهرة. تعلم كيف تتقدم لوظيفة بثقة.",
      vocabulary: [
        { de: "die Stellenanzeige", ar: "إعلان الوظيفة", example: "Ich habe eine Stellenanzeige gelesen." },
        { de: "die Bewerbung", ar: "طلب التوظيف", example: "Ich schreibe eine Bewerbung." },
        { de: "der Lebenslauf (CV)", ar: "السيرة الذاتية", example: "Mein Lebenslauf ist aktuell." },
        { de: "das Vorstellungsgespräch", ar: "مقابلة العمل", example: "Ich habe morgen ein Vorstellungsgespräch." },
        { de: "die Berufserfahrung", ar: "الخبرة المهنية", example: "Ich habe 3 Jahre Berufserfahrung." },
        { de: "die Qualifikation", ar: "المؤهل", example: "Welche Qualifikationen haben Sie?" },
        { de: "das Gehalt", ar: "الراتب", example: "Was ist das Gehalt für diese Stelle?" },
        { de: "der Vertrag", ar: "العقد", example: "Ich habe einen Arbeitsvertrag unterschrieben." },
        { de: "der Arbeitgeber", ar: "صاحب العمل", example: "Mein Arbeitgeber ist sehr fair." },
        { de: "der Arbeitnehmer", ar: "الموظف / العامل", example: "Arbeitnehmer haben viele Rechte in Deutschland." },
      ],
      dialogue: [
        { speaker: "مسؤول توظيف", de: "Erzählen Sie mir etwas über sich.", ar: "أخبرني شيئاً عن نفسك." },
        { speaker: "مرشح", de: "Ich bin Ingenieur mit 5 Jahren Erfahrung in der IT-Branche.", ar: "أنا مهندس مع 5 سنوات خبرة في قطاع تكنولوجيا المعلومات." },
        { speaker: "مسؤول توظيف", de: "Warum möchten Sie bei uns arbeiten?", ar: "لماذا تريد العمل معنا؟" },
        { speaker: "مرشح", de: "Weil Ihr Unternehmen innovativ ist und ich mich weiterentwickeln möchte.", ar: "لأن شركتكم مبتكرة وأريد تطوير نفسي." },
      ],
      tips: [
        "في ألمانيا السيرة الذاتية تتضمن صورة وتاريخ الميلاد",
        "خطاب التقديم (Anschreiben) إلزامي في معظم الطلبات",
        "Ich bewerbe mich für die Stelle als... = أتقدم لوظيفة...",
      ],
    },
  },
  {
    id: 2, title: "التعبير عن الرأي", titleDe: "Meinung ausdrücken",
    description: "تعلم كيف تعبر عن رأيك وتناقش المواضيع المختلفة",
    category: "تواصل", duration: "30 دقيقة",
    content: {
      intro: "القدرة على التعبير عن الرأي والنقاش أساسية في اللغة B1.",
      vocabulary: [
        { de: "Ich meine, dass...", ar: "أعتقد أن...", example: "Ich meine, dass Deutsch schwierig aber schön ist." },
        { de: "Ich bin der Meinung, dass...", ar: "أرى أن...", example: "Ich bin der Meinung, dass Bildung wichtig ist." },
        { de: "Meiner Meinung nach...", ar: "في رأيي...", example: "Meiner Meinung nach ist Sport gesund." },
        { de: "Ich stimme zu.", ar: "أوافق.", example: "Ich stimme dir völlig zu." },
        { de: "Ich stimme nicht zu.", ar: "لا أوافق.", example: "Da stimme ich leider nicht zu." },
        { de: "Das sehe ich anders.", ar: "أرى ذلك بطريقة مختلفة.", example: "Das sehe ich etwas anders." },
        { de: "einerseits... andererseits", ar: "من جهة... من جهة أخرى", example: "Einerseits ist es gut, andererseits hat es Nachteile." },
        { de: "Ich halte... für...", ar: "أعتبر... ...", example: "Ich halte das für eine gute Idee." },
      ],
      tips: [
        "في النقاش الألماني: احترام الرأي الآخر أساسي",
        "Ich verstehe Ihre Meinung, aber... = أفهم رأيك، لكن...",
        "Können Sie das erklären? = هل يمكنك شرح ذلك؟",
      ],
    },
  },
  {
    id: 3, title: "المبني للمجهول", titleDe: "Das Passiv",
    description: "تعلم بناء الجمل بالمبني للمجهول في الألمانية",
    category: "قواعد", duration: "35 دقيقة",
    content: {
      intro: "المبني للمجهول (Passiv) يُستخدم كثيراً في الأسلوب الرسمي والكتابة.",
      vocabulary: [
        { de: "Das Buch wird gelesen.", ar: "الكتاب يُقرأ.", example: "Das Buch wird von vielen Menschen gelesen." },
        { de: "Die Tür wird geöffnet.", ar: "الباب يُفتح.", example: "Die Tür wird um 9 Uhr geöffnet." },
        { de: "Das Auto wurde repariert.", ar: "السيارة أُصلحت.", example: "Das Auto wurde gestern repariert." },
        { de: "Der Brief wurde geschrieben.", ar: "الرسالة كُتبت.", example: "Der Brief wurde heute Morgen geschrieben." },
      ],
      grammar: [
        { rule: "Passiv Präsens: werden + Partizip II", example: "Das Essen wird gekocht.", translation: "الطعام يُطبخ." },
        { rule: "Passiv Präteritum: wurde + Partizip II", example: "Das Haus wurde gebaut.", translation: "البيت بُني." },
        { rule: "الفاعل يُذكر بـ 'von'", example: "Das Buch wurde von Schiller geschrieben.", translation: "الكتاب كُتب من طرف شيلر." },
      ],
      tips: [
        "الفاعل ليس مهماً أو غير معروف في المبني للمجهول",
        "يُستخدم كثيراً في التعليمات والأخبار",
        "Hier wird nicht geraucht. = التدخين ممنوع هنا.",
      ],
    },
  },
  {
    id: 4, title: "الترفيه والهوايات", titleDe: "Freizeit und Hobbys",
    description: "تحدث عن هواياتك وكيف تقضي وقت فراغك",
    category: "ثقافة", duration: "25 دقيقة",
    content: {
      intro: "الترفيه والهوايات موضوع محادثة ممتاز لبدء الصداقات.",
      vocabulary: [
        { de: "das Hobby", ar: "الهواية", example: "Was machst du in deiner Freizeit?" },
        { de: "Sport treiben", ar: "ممارسة الرياضة", example: "Ich treibe dreimal die Woche Sport." },
        { de: "Musik hören", ar: "الاستماع للموسيقى", example: "Ich höre gern arabische Musik." },
        { de: "reisen", ar: "السفر", example: "Ich reise sehr gern." },
        { de: "lesen", ar: "القراءة", example: "Ich lese jeden Abend ein Buch." },
        { de: "kochen", ar: "الطبخ", example: "Kochen ist mein Hobby." },
        { de: "fotografieren", ar: "التصوير", example: "Ich fotografiere die Natur." },
        { de: "tanzen", ar: "الرقص", example: "Wir gehen am Wochenende tanzen." },
        { de: "spielen", ar: "اللعب", example: "Ich spiele Gitarre und Fußball." },
        { de: "das Kino", ar: "السينما", example: "Ich gehe oft ins Kino." },
      ],
      tips: [
        "Ich interessiere mich für... = أنا مهتم بـ...",
        "Mein größtes Interesse ist... = اهتمامي الأكبر هو...",
        "Hast du Lust, ...zu machen? = هل تريد أن...؟",
      ],
    },
  },
  {
    id: 5, title: "البيئة والمناخ", titleDe: "Umwelt und Klimawandel",
    description: "تعلم التحدث عن البيئة والتغير المناخي",
    category: "ثقافة", duration: "30 دقيقة",
    content: {
      intro: "البيئة موضوع مهم جداً في ألمانيا. الألمان من أكثر الشعوب اهتماماً بالبيئة.",
      vocabulary: [
        { de: "der Klimawandel", ar: "تغير المناخ", example: "Der Klimawandel ist ein globales Problem." },
        { de: "die Umweltverschmutzung", ar: "التلوث البيئي", example: "Wir müssen die Umweltverschmutzung bekämpfen." },
        { de: "erneuerbare Energie", ar: "الطاقة المتجددة", example: "Deutschland investiert in erneuerbare Energie." },
        { de: "recyceln", ar: "إعادة التدوير", example: "In Deutschland recycelt man viel." },
        { de: "der Müll", ar: "القمامة / النفايات", example: "Bitte werfen Sie den Müll in den richtigen Behälter." },
        { de: "sparen", ar: "يوفر / يقتصد", example: "Wir müssen Energie sparen." },
        { de: "nachhaltig", ar: "مستدام", example: "Nachhaltigkeit ist wichtig für die Zukunft." },
        { de: "der Treibhauseffekt", ar: "ظاهرة الاحتباس الحراري", example: "Der Treibhauseffekt erwärmt die Erde." },
      ],
      tips: [
        "في ألمانيا القمامة مفصولة: Papier، Glas، Bio، Restmüll",
        "Bio (عضوي) من القيم الهامة للمستهلك الألماني",
        "Fahrrad fahren statt Auto fahren = ركوب الدراجة بدلاً من السيارة",
      ],
    },
  },
  {
    id: 6, title: "Konjunktiv II — الأسلوب الشرطي", titleDe: "Konjunktiv II",
    description: "تعلم التعبير عن الفروض والتمنيات والأدب",
    category: "قواعد", duration: "35 دقيقة",
    content: {
      intro: "Konjunktiv II يُستخدم للتمني والفروض والطلبات المهذبة.",
      vocabulary: [
        { de: "Ich würde gern...", ar: "أود...", example: "Ich würde gern nach Deutschland reisen." },
        { de: "Könnten Sie...?", ar: "هل يمكنك...؟", example: "Könnten Sie mir helfen?" },
        { de: "Ich hätte gern...", ar: "أود أن يكون عندي...", example: "Ich hätte gern mehr Zeit." },
        { de: "Wenn ich...wäre/hätte...", ar: "لو كنت / لو كان عندي...", example: "Wenn ich reich wäre, würde ich reisen." },
        { de: "Das wäre schön.", ar: "سيكون ذلك رائعاً.", example: "Das wäre sehr schön!" },
        { de: "Ich sollte...", ar: "يجب أن...", example: "Ich sollte mehr schlafen." },
      ],
      grammar: [
        { rule: "würde + Infinitiv للفعل الرئيسي", example: "Ich würde gern tanzen.", translation: "أود الرقص." },
        { rule: "wäre = sein بصيغة Konjunktiv", example: "Das wäre gut.", translation: "هذا سيكون جيداً." },
        { rule: "hätte = haben بصيغة Konjunktiv", example: "Ich hätte mehr Geld.", translation: "لو كان لدي أموال أكثر." },
      ],
      tips: [
        "Konjunktiv II مهم جداً للأدب والرفق في الطلبات",
        "Könnten Sie... = أكثر أدباً من Können Sie...",
        "Ich möchte... من Konjunktiv II لـ mögen",
      ],
    },
  },
  {
    id: 7, title: "الأخبار والإعلام", titleDe: "Nachrichten und Medien",
    description: "تعلم كيف تتحدث عن الأخبار ووسائل الإعلام",
    category: "ثقافة", duration: "30 دقيقة",
    content: {
      intro: "متابعة الأخبار بالألمانية تحسن لغتك وتوسع معرفتك بالثقافة.",
      vocabulary: [
        { de: "die Nachrichten", ar: "الأخبار", example: "Ich schaue jeden Abend die Nachrichten." },
        { de: "die Zeitung", ar: "الجريدة", example: "Ich lese die Zeitung morgens." },
        { de: "die Zeitschrift", ar: "المجلة", example: "Diese Zeitschrift ist sehr interessant." },
        { de: "das Internet", ar: "الإنترنت", example: "Ich lese Nachrichten im Internet." },
        { de: "die Schlagzeile", ar: "العنوان الرئيسي", example: "Die Schlagzeile ist wichtig." },
        { de: "berichten", ar: "يُخبر / يُرسل تقريراً", example: "Der Reporter berichtet aus Berlin." },
        { de: "der Journalist / die Journalistin", ar: "الصحفي", example: "Meine Freundin ist Journalistin." },
        { de: "das Interview", ar: "المقابلة / التحقيق", example: "Der Politiker gibt ein Interview." },
      ],
      tips: [
        "Deutsche Welle (DW) = قناة إخبارية ألمانية بلغات عدة",
        "تابع الأخبار البطيئة: nachrichtenleicht.de",
        "das Erste، ZDF = أهم القنوات التلفزيونية الألمانية",
      ],
    },
  },
  {
    id: 8, title: "الجمل الشرطية والسببية", titleDe: "Kausalsätze und Konditionalsätze",
    description: "تعلم ربط الجمل بروابط السبب والشرط",
    category: "قواعد", duration: "35 دقيقة",
    content: {
      intro: "ربط الجمل يجعل حديثك أكثر احترافية وطلاقة.",
      vocabulary: [
        { de: "weil (لأن)", ar: "لأن", example: "Ich lerne Deutsch, weil ich in Deutschland arbeiten möchte." },
        { de: "da (بما أن)", ar: "بما أن / حيث أن", example: "Da es regnet, bleibe ich zu Hause." },
        { de: "denn (إذ / لأن)", ar: "إذ / لأن", example: "Ich bleibe zu Hause, denn ich bin krank." },
        { de: "wenn (إذا / عندما)", ar: "إذا / عندما", example: "Wenn ich Zeit habe, lese ich Bücher." },
        { de: "falls (في حال)", ar: "في حال", example: "Falls es regnet, nehmen wir ein Taxi." },
        { de: "obwohl (رغم أن)", ar: "رغم أن / على الرغم من", example: "Obwohl er müde ist, arbeitet er weiter." },
        { de: "damit (لكي)", ar: "لكي", example: "Ich lerne, damit ich die Prüfung bestehe." },
        { de: "trotzdem (رغم ذلك)", ar: "رغم ذلك / مع ذلك", example: "Es regnet, trotzdem gehe ich spazieren." },
      ],
      grammar: [
        { rule: "weil، da، obwohl: الفعل في نهاية الجملة الفرعية", example: "Ich lerne, weil ich den Test bestehen will.", translation: "أدرس لأنني أريد اجتياز الاختبار." },
        { rule: "denn: ترتيب الجملة عادي", example: "Ich lerne, denn ich will den Test bestehen.", translation: "أدرس إذ أريد اجتياز الاختبار." },
      ],
      tips: [
        "weil و denn يعبران عن نفس المعنى لكن ببنى مختلفة",
        "obwohl = رغم أن (تعبر عن التناقض)",
        "الفعل في الجملة الفرعية دائماً في الآخر مع: weil، da، obwohl، wenn، damit",
      ],
    },
  },
];

const b2Lessons: Lesson[] = [
  {
    id: 1, title: "الكتابة الأكاديمية", titleDe: "Akademisches Schreiben",
    description: "تعلم أسلوب الكتابة الأكاديمية والرسمية بالألمانية",
    category: "كتابة", duration: "40 دقيقة",
    content: {
      intro: "الكتابة الأكاديمية مهارة أساسية للدراسة في الجامعات الألمانية.",
      vocabulary: [
        { de: "die Einleitung", ar: "المقدمة", example: "Die Einleitung sollte das Thema vorstellen." },
        { de: "der Hauptteil", ar: "الجزء الرئيسي", example: "Im Hauptteil werden die Argumente dargestellt." },
        { de: "die Schlussfolgerung", ar: "الخاتمة / الاستنتاج", example: "Die Schlussfolgerung fasst die Ergebnisse zusammen." },
        { de: "das Argument", ar: "الحجة / الدليل", example: "Dieses Argument ist überzeugend." },
        { de: "die These", ar: "الفرضية", example: "Die These dieser Arbeit ist klar." },
        { de: "belegen", ar: "يثبت / يؤيد بأدلة", example: "Diese Aussage muss belegt werden." },
        { de: "zitieren", ar: "يقتبس", example: "Ich zitiere aus Goethes Werk." },
        { de: "das Literaturverzeichnis", ar: "قائمة المراجع", example: "Das Literaturverzeichnis muss vollständig sein." },
        { de: "die Forschung", ar: "البحث العلمي", example: "Neue Forschung zeigt interessante Ergebnisse." },
        { de: "analysieren", ar: "يحلل", example: "Wir analysieren die Daten sorgfältig." },
      ],
      grammar: [
        { rule: "الأسلوب الرسمي: جمل طويلة مترابطة", example: "Wie aus der Analyse hervorgeht, bestätigt sich die These.", translation: "كما يتضح من التحليل، تتأكد الفرضية." },
        { rule: "استخدام المبني للمجهول في الكتابة الأكاديمية", example: "Die Daten wurden analysiert.", translation: "تم تحليل البيانات." },
      ],
      tips: [
        "تجنب اللغة العامية في الكتابة الأكاديمية",
        "استخدم روابط منطقية: zunächst، dann، abschließend",
        "الجمل في الكتابة الأكاديمية أطول وأكثر تعقيداً",
      ],
    },
  },
  {
    id: 2, title: "النقاش والجدل", titleDe: "Diskussion und Debatte",
    description: "تعلم كيف تشارك في نقاشات معقدة وتقدم حججاً مقنعة",
    category: "تواصل", duration: "35 دقيقة",
    content: {
      intro: "المشاركة في النقاشات تتطلب مهارات لغوية متقدمة. تعلمها هنا.",
      vocabulary: [
        { de: "Im Großen und Ganzen...", ar: "على العموم...", example: "Im Großen und Ganzen bin ich damit einverstanden." },
        { de: "Es ist zu beachten, dass...", ar: "تجدر الإشارة إلى أن...", example: "Es ist zu beachten, dass die Situation komplex ist." },
        { de: "Hinzu kommt, dass...", ar: "يُضاف إلى ذلك أن...", example: "Hinzu kommt, dass die Kosten steigen." },
        { de: "Im Gegensatz dazu...", ar: "على النقيض من ذلك...", example: "Im Gegensatz dazu zeigen andere Studien..." },
        { de: "Es steht außer Frage, dass...", ar: "لا شك في أن...", example: "Es steht außer Frage, dass Bildung wichtig ist." },
        { de: "Ich möchte betonen, dass...", ar: "أود التأكيد على أن...", example: "Ich möchte betonen, dass das nicht stimmt." },
        { de: "zusammenfassend", ar: "خلاصة القول / باختصار", example: "Zusammenfassend lässt sich sagen, dass..." },
        { de: "darüber hinaus", ar: "فضلاً عن ذلك", example: "Darüber hinaus gibt es weitere Probleme." },
      ],
      tips: [
        "ابدأ بتلخيص رأي الطرف الآخر قبل الرد عليه",
        "استخدم أمثلة ملموسة لتقوية حججك",
        "Ich verstehe Ihren Standpunkt, aber... = أفهم موقفك، لكن...",
      ],
    },
  },
  {
    id: 3, title: "الأسلوب الكتابي المتقدم", titleDe: "Fortgeschrittener Schreibstil",
    description: "تعلم تقنيات الكتابة الإبداعية والرسمية المتقدمة",
    category: "كتابة", duration: "40 دقيقة",
    content: {
      intro: "الكتابة المتقدمة تميزك في الامتحانات الرسمية وسوق العمل.",
      vocabulary: [
        { de: "dennoch", ar: "ومع ذلك / غير أن", example: "Es war schwierig, dennoch habe ich es geschafft." },
        { de: "infolgedessen", ar: "نتيجة لذلك", example: "Infolgedessen mussten wir den Plan ändern." },
        { de: "demzufolge", ar: "وفقاً لذلك", example: "Demzufolge ist die Situation ernst." },
        { de: "allerdings", ar: "غير أن / بيد أن", example: "Das ist gut, allerdings gibt es Probleme." },
        { de: "insbesondere", ar: "لا سيما / خاصة", example: "Insbesondere die jungen Menschen sind betroffen." },
        { de: "diesbezüglich", ar: "في هذا الشأن", example: "Diesbezüglich haben wir Bedenken." },
        { de: "dementsprechend", ar: "وفق ذلك / بناء عليه", example: "Dementsprechend wurde entschieden..." },
        { de: "nach wie vor", ar: "لا تزال / مازالت", example: "Das Problem besteht nach wie vor." },
      ],
      tips: [
        "تجنب تكرار نفس الكلمات — استخدم مرادفات",
        "الروابط المتقدمة تجعل نصك أكثر احترافية",
        "اقرأ الصحف الألمانية لاستيعاب الأسلوب الرسمي",
      ],
    },
  },
  {
    id: 4, title: "المواضيع الاجتماعية والسياسية", titleDe: "Gesellschaft und Politik",
    description: "تعلم مناقشة المواضيع الاجتماعية والسياسية بالألمانية",
    category: "ثقافة", duration: "35 دقيقة",
    content: {
      intro: "القدرة على مناقشة المواضيع الكبيرة دليل على إتقانك للغة.",
      vocabulary: [
        { de: "die Demokratie", ar: "الديمقراطية", example: "Deutschland ist eine Demokratie." },
        { de: "die Gleichstellung", ar: "المساواة", example: "Gleichstellung von Mann und Frau ist wichtig." },
        { de: "die Integration", ar: "الاندماج", example: "Integration ist ein komplexes Thema." },
        { de: "die Migration", ar: "الهجرة", example: "Migration ist ein globales Phänomen." },
        { de: "die Globalisierung", ar: "العولمة", example: "Die Globalisierung hat Vor- und Nachteile." },
        { de: "die Arbeitslosigkeit", ar: "البطالة", example: "Die Arbeitslosigkeit ist gesunken." },
        { de: "die Inflation", ar: "التضخم", example: "Die Inflation betrifft alle." },
        { de: "der Wohlfahrtsstaat", ar: "دولة الرفاه", example: "Deutschland hat einen starken Wohlfahrtsstaat." },
      ],
      tips: [
        "تجنب التعليقات الحادة في النقاشات السياسية مع الألمان",
        "الألمان يُقدّرون المعلومة الموثقة أكثر من الرأي الشخصي",
        "In Deutschland herrscht Redefreiheit. = حرية التعبير مكفولة في ألمانيا.",
      ],
    },
  },
  {
    id: 5, title: "اللغة الألمانية في بيئة العمل", titleDe: "Deutsch im Berufsleben",
    description: "تعلم اللغة المستخدمة في بيئة العمل الاحترافية",
    category: "عمل", duration: "40 دقيقة",
    content: {
      intro: "اللغة المهنية تختلف عن اللغة اليومية. تعلمها لتكون محترفاً في مكان عملك.",
      vocabulary: [
        { de: "die Besprechung / das Meeting", ar: "الاجتماع", example: "Wir haben morgen eine Besprechung." },
        { de: "die Präsentation", ar: "العرض التقديمي", example: "Ich halte eine Präsentation über das Projekt." },
        { de: "das Protokoll", ar: "محضر الاجتماع", example: "Wer schreibt das Protokoll?" },
        { de: "die Deadline / der Abgabetermin", ar: "الموعد النهائي", example: "Die Deadline ist nächsten Freitag." },
        { de: "der Kollege / die Kollegin", ar: "الزميل / الزميلة", example: "Meine Kollegen sind sehr hilfsbereit." },
        { de: "der Vorgesetzte", ar: "المشرف / الرئيس", example: "Mein Vorgesetzter ist sehr fair." },
        { de: "das Projekt", ar: "المشروع", example: "Wir arbeiten an einem wichtigen Projekt." },
        { de: "die Geschäftsreise", ar: "رحلة العمل", example: "Ich mache nächste Woche eine Geschäftsreise nach Wien." },
        { de: "der Umsatz", ar: "رقم المبيعات / الإيرادات", example: "Der Umsatz ist gestiegen." },
        { de: "die Strategie", ar: "الاستراتيجية", example: "Wir brauchen eine neue Strategie." },
      ],
      tips: [
        "Darf ich kurz unterbrechen? = هل يمكنني المقاطعة لحظة؟",
        "Könnten wir das vertagen? = هل يمكن تأجيل هذا؟",
        "Das steht nicht auf der Tagesordnung. = هذا ليس في جدول الأعمال.",
      ],
    },
  },
  {
    id: 6, title: "الأدب والثقافة الألمانية", titleDe: "Deutsche Literatur und Kultur",
    description: "تعرف على أبرز ملامح الثقافة والأدب الألماني",
    category: "ثقافة", duration: "35 دقيقة",
    content: {
      intro: "الثقافة الألمانية عريقة وغنية. فهمها يعمق صلتك باللغة والمجتمع.",
      vocabulary: [
        { de: "Johann Wolfgang von Goethe", ar: "غوته — أعظم شعراء الألمانية", example: "Goethe hat 'Faust' geschrieben." },
        { de: "Friedrich Schiller", ar: "شيلر — شاعر وكاتب مسرحي كبير", example: "Schiller ist bekannt für 'Wilhelm Tell'." },
        { de: "Beethoven", ar: "بيتهوفن — عملاق الموسيقى الكلاسيكية", example: "Beethovens 9. Symphonie ist weltberühmt." },
        { de: "das Oktoberfest", ar: "مهرجان أكتوبر — أشهر مهرجان ألماني", example: "Das Oktoberfest findet in München statt." },
        { de: "Karneval / Fasching", ar: "مهرجان الكرنفال", example: "Karneval ist in Köln besonders beliebt." },
        { de: "die Berliner Mauer", ar: "جدار برلين", example: "Die Mauer fiel 1989." },
        { de: "der Expressionismus", ar: "التعبيرية (تيار فني ألماني)", example: "Der Expressionismus war eine wichtige Kunstrichtung." },
        { de: "das Märchen", ar: "الحكاية الشعبية", example: "Die Brüder Grimm haben viele Märchen gesammelt." },
      ],
      tips: [
        "قراءة الأدب الألماني تُثري مفرداتك بشكل كبير",
        "Grimms Märchen = حكايات الأخوين غريم (مشهورة عالمياً)",
        "فهم التاريخ الألماني يساعد على فهم المجتمع",
      ],
    },
  },
  {
    id: 7, title: "التكنولوجيا والمستقبل", titleDe: "Technologie und Zukunft",
    description: "ناقش موضوعات التكنولوجيا والذكاء الاصطناعي بالألمانية",
    category: "ثقافة", duration: "35 دقيقة",
    content: {
      intro: "التكنولوجيا تغير العالم. تعلم كيف تناقش هذه المواضيع بالألمانية.",
      vocabulary: [
        { de: "die Künstliche Intelligenz (KI)", ar: "الذكاء الاصطناعي", example: "KI verändert die Arbeitswelt." },
        { de: "die Digitalisierung", ar: "التحول الرقمي", example: "Die Digitalisierung ist in Deutschland ein wichtiges Thema." },
        { de: "das autonome Fahren", ar: "القيادة الذاتية", example: "Autonome Autos werden bald normal sein." },
        { de: "die App", ar: "التطبيق", example: "Diese App ist sehr nützlich." },
        { de: "der Datenschutz", ar: "حماية البيانات", example: "Datenschutz ist in Deutschland sehr wichtig." },
        { de: "der Algorithmus", ar: "الخوارزمية", example: "Algorithmen bestimmen, was wir sehen." },
        { de: "die Cloud", ar: "السحابة الإلكترونية", example: "Ich speichere alles in der Cloud." },
        { de: "der Start-up", ar: "شركة ناشئة", example: "Deutschland hat viele innovative Start-ups." },
      ],
      tips: [
        "ألمانيا رائدة في قطاع التكنولوجيا الصناعية (Industrie 4.0)",
        "GDPR/DSGVO = قانون حماية البيانات الأوروبي",
        "تعلم المصطلحات التقنية يفيدك في سوق العمل الألماني",
      ],
    },
  },
  {
    id: 8, title: "الحياة في ألمانيا — نصائح عملية", titleDe: "Leben in Deutschland",
    description: "كل ما تحتاج معرفته للعيش والاندماج في ألمانيا",
    category: "ثقافة", duration: "35 دقيقة",
    content: {
      intro: "الانتقال للعيش في ألمانيا يتطلب معرفة النظام والعادات والقوانين.",
      vocabulary: [
        { de: "die Anmeldung", ar: "تسجيل الإقامة", example: "Ich muss mich beim Bürgeramt anmelden." },
        { de: "das Finanzamt", ar: "مصلحة الضرائب", example: "Ich muss eine Steuererklärung machen." },
        { de: "die Krankenversicherung", ar: "التأمين الصحي", example: "Jeder braucht eine Krankenversicherung." },
        { de: "das Konto eröffnen", ar: "فتح حساب بنكي", example: "Ich möchte ein Konto eröffnen." },
        { de: "die Behörde", ar: "الجهة الحكومية / الإدارة", example: "Ich muss zur Behörde gehen." },
        { de: "das Visum / die Aufenthaltserlaubnis", ar: "التأشيرة / تصريح الإقامة", example: "Ich brauche eine Aufenthaltserlaubnis." },
        { de: "die Wohnung mieten", ar: "استئجار شقة", example: "Ich suche eine Wohnung zur Miete." },
        { de: "der Mietvertrag", ar: "عقد الإيجار", example: "Bitte lesen Sie den Mietvertrag sorgfältig." },
      ],
      tips: [
        "Anmeldung (تسجيل الإقامة) إلزامي خلال 14 يوماً من الوصول",
        "Steuer-ID (رقم الهوية الضريبية) ضروري لبدء العمل",
        "احتفظ بكل الوثائق المهمة — الألمان يحبون الأوراق!",
      ],
    },
  },
];

export const levels: Level[] = [
  {
    id: "A1", name: "مبتدئ", nameAr: "مبتدئ", nameDe: "Anfänger",
    color: "text-green-700", bgColor: "bg-green-50", borderColor: "border-green-300",
    description: "أول خطوة في الألمانية — التعارف، الأرقام، الألوان، الأسرة",
    hours: "12 ساعة", lessons: a1Lessons,
  },
  {
    id: "A2", name: "أساسي", nameAr: "أساسي", nameDe: "Grundstufe",
    color: "text-blue-700", bgColor: "bg-blue-50", borderColor: "border-blue-300",
    description: "التسوق، الاتجاهات، الطعام، الوقت والمواعيد",
    hours: "18 ساعة", lessons: a2Lessons,
  },
  {
    id: "B1", name: "متوسط", nameAr: "متوسط", nameDe: "Mittelstufe",
    color: "text-orange-700", bgColor: "bg-orange-50", borderColor: "border-orange-300",
    description: "العمل، الصحة، الترفيه، والتعبير عن الرأي",
    hours: "22 ساعة", lessons: b1Lessons,
  },
  {
    id: "B2", name: "فوق المتوسط", nameAr: "فوق المتوسط", nameDe: "Fortgeschritten",
    color: "text-purple-700", bgColor: "bg-purple-50", borderColor: "border-purple-300",
    description: "نقاشات معقدة، أخبار، موضوعات أكاديمية ومهنية",
    hours: "28 ساعة", lessons: b2Lessons,
  },
];
